package Model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DBHandler.DBConnection;
import Entity.Animal;
import Entity.Diet;
import Entity.Enclosure;
import Entity.Keeper;
import Entity.Species;

public class UpdateQuery {
	private static Connection con;
	private static void openConnection() throws ClassNotFoundException, SQLException {
		con=DBConnection.getConnection();
	}
	private static void closeConnection() throws SQLException {
		con.close();
	}
	public static int updateKeeperInfoByID(Keeper keeper) throws ClassNotFoundException, SQLException {
		openConnection();

		int row = 0;

		String query = "update keeper set name=?,dob=?,email=?,address=?,keeper_rank=?,phno=? where keeper_id=?";

		PreparedStatement pstmt = con.prepareStatement(query);
		
		pstmt.setString(1, keeper.getName());
		pstmt.setDate(2, Date.valueOf(keeper.getDob()));
		pstmt.setString(3, keeper.getEmail());
		pstmt.setString(4, keeper.getAddress());
		pstmt.setString(5, keeper.getKeeper_rank());
		pstmt.setString(6, keeper.getPhno());
		
		pstmt.setInt(7, keeper.getKeeper_id());
		
		row=pstmt.executeUpdate();
		
		closeConnection();
		return row;

	}
	public static int updateSpeciesInfoByID(Species species) throws ClassNotFoundException, SQLException {
		openConnection();
			int row = 0;
			
			String query = "update species set species_type=?,species_group=?,lifestyle=?,conservation_status=? where species_id=?";
								
			PreparedStatement pstmt = con.prepareStatement(query);
			
			pstmt.setString(1, species.getType());
			pstmt.setString(2, species.getGroup());
			pstmt.setString(3, species.getLifestyle());
			pstmt.setString(4, species.getConservation());
			pstmt.setInt(5, species.getSpecies_id());
			
			row=pstmt.executeUpdate();
			
			closeConnection();
			return row;
		
	}
	public static int updateDietInfoByID(Diet diet) throws ClassNotFoundException, SQLException {
		openConnection();
		int row=0;
		
String query="update diet set diet_type=?,feeds_per_day=? where diet_id=?";
		PreparedStatement pstmt=con.prepareStatement(query);
		
		pstmt.setString(1, diet.getType());
		pstmt.setInt(2, diet.getFeeds_per_day());
		pstmt.setInt(3,diet.getDiet_id());
		
		row=pstmt.executeUpdate();
		closeConnection();
		return row;
	}
	public static int updateEnclosureInfoByID(Enclosure enclosure) throws ClassNotFoundException, SQLException {
		openConnection();
int row=0;
		
		String query="update enclosure set enclosure_type=?,location=? where enclosure_id=?";
		
		PreparedStatement pstmt=con.prepareStatement(query);
		
		System.out.println(enclosure.getEnclosure_id()+" " + enclosure.getLocation());
		
		pstmt.setString(1, enclosure.getType());
		pstmt.setString(2, enclosure.getLocation());
		pstmt.setInt(3, enclosure.getEnclosure_id());
		
		row=pstmt.executeUpdate(); 
		System.out.println(row);

		closeConnection();
		return row;
	}
	public static int updateAnimalInfoByID(Animal animal) throws ClassNotFoundException, SQLException {
		openConnection();
		int row=0;
		String query="update animal set name=?,gender=?,date_of_arrival=?,keeper_id=?,species_id=?,enclosure_id=?,diet_id=?";
		PreparedStatement pstmt = con.prepareStatement(query);
		pstmt.setString(1, animal.getName());
		pstmt.setString(2,animal.getGender());
		pstmt.setDate(3,Date.valueOf(animal.getDate_of_arrival()));
		pstmt.setInt(4, animal.getKeeper_id());
		pstmt.setInt(5,animal.getSpecies_id());
		pstmt.setInt(6, animal.getEnclosure_id());
		pstmt.setInt(7, animal.getDiet_id());
		
		row = pstmt.executeUpdate();
		
		closeConnection();
		
		return row;
	}
	
}
