package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DBHandler.DBConnection;
import Entity.Animal;
import Entity.Diet;
import Entity.Enclosure;
import Entity.Keeper;
import Entity.Report1;
import Entity.Report2;
import Entity.Species;

public class SelectQueries {
	private static Connection con;
	private static void openConnection() throws ClassNotFoundException, SQLException {
		con=DBConnection.getConnection();
	}
	private static void closeConnection() throws SQLException {
		con.close();
	}
	/**
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static ArrayList<Keeper>getAllKeeperInfo() throws SQLException, ClassNotFoundException{
		openConnection();
		
		ArrayList<Keeper>myList=new ArrayList<>();
		
		String query = "select *from keeper";
		
		PreparedStatement pstmt=con.prepareStatement(query);
		ResultSet rs=pstmt.executeQuery();
		
		if(!rs.isBeforeFirst()) {
			return null;
		}
		
		while(rs.next()) {
			Keeper keeper=new Keeper();
			
			keeper.setKeeper_id(rs.getInt("keeper_id"));
			keeper.setKeeper_rank(rs.getString("keeper_rank"));
			keeper.setAddress(rs.getString("address"));
			keeper.setEmail(rs.getString("email"));
			keeper.setName(rs.getString("name"));
			keeper.setPhno(rs.getString("phno"));
			keeper.setDob(String.valueOf( rs.getDate("dob")));
			
			myList.add(keeper);
		}
		
		closeConnection();
		return myList;
	}
	public static ArrayList<Species>getAllSpeciesInfo() throws ClassNotFoundException, SQLException{
		openConnection();
		ArrayList<Species>myList=new ArrayList<>();
		
		String query="select*from species";
		PreparedStatement pstmt=con.prepareStatement(query);
		ResultSet rs=pstmt.executeQuery();
		
		if(!rs.isBeforeFirst()) {
			return null;
		}
		
		while(rs.next()) {
			Species species=new Species();
			
			species.setSpecies_id(rs.getInt("species_id"));
			species.setType(rs.getString("species_type"));
			species.setGroup(rs.getString("species_group"));
			species.setLifestyle(rs.getString("lifestyle"));
			species.setConservation(rs.getString("conservation_status"));
			
			myList.add(species);
		}
		closeConnection();
		return myList;
	}
		public static ArrayList<Enclosure>getAllEnclosuresInfo() throws ClassNotFoundException, SQLException{
			openConnection();
			ArrayList<Enclosure>myList=new ArrayList<>();
			
			String query="select * from enclosure";
			PreparedStatement pstmt=con.prepareStatement(query);
			ResultSet rs=pstmt.executeQuery();
			
			if(!rs.isBeforeFirst()) {
				return null;
			}
			while(rs.next()) {
				Enclosure enclosure=new Enclosure();
				
				enclosure.setEnclosure_id(rs.getInt("enclosure_id"));
				enclosure.setLocation(rs.getString("location"));
				enclosure.setType(rs.getString("enclosure_type"));
			
				
				myList.add(enclosure);
			}
			closeConnection();
			return myList;
		}
	public static ArrayList<Diet>getAllDietInfo() throws ClassNotFoundException, SQLException{
		openConnection();
		ArrayList<Diet>myList=new ArrayList<>();
		
		String query="select * from diet";
		PreparedStatement pstmt=con.prepareStatement(query);
		ResultSet rs=pstmt.executeQuery();
		
		if(!rs.isBeforeFirst()) {
			return null;
		}
		while(rs.next()) {
			Diet diet=new Diet();
			diet.setDiet_id(rs.getInt("diet_id"));
			diet.setType(rs.getString("diet_type"));
			diet.setFeeds_per_day(rs.getInt("feeds_per_day"));
			
			myList.add(diet);
		}
		
		closeConnection();
		return myList;
	}
public static ArrayList<Integer> getAllSpeciesID() throws ClassNotFoundException, SQLException{
		
		openConnection();
		
		ArrayList<Integer> myList = new ArrayList<>();
		
		String query = "select species_id from species";
		PreparedStatement pstmt = con.prepareStatement(query);
		ResultSet rs = pstmt.executeQuery();
		
		if(!rs.isBeforeFirst()) {
			return null;
		}
		
		while(rs.next()) {
			myList.add(rs.getInt("species_id"));
		}
		
		
		closeConnection();
		
		return myList;		
	}
	
	public static ArrayList<Integer> getAllKeeperID() throws ClassNotFoundException, SQLException{
		openConnection();
		
		ArrayList<Integer> myList = new ArrayList<>();
		
		String query = "select keeper_id from keeper";
		PreparedStatement pstmt = con.prepareStatement(query);
		ResultSet rs = pstmt.executeQuery();
		
		if(!rs.isBeforeFirst()) {
			return null;
		}
		
		while(rs.next()) {
			myList.add(rs.getInt("keeper_id"));
		}
		
		
		closeConnection();
		
		return myList;
	}
	
	public static ArrayList<Integer> getAllEnclosureID() throws ClassNotFoundException, SQLException{
		openConnection();
		
		ArrayList<Integer> myList = new ArrayList<>();
		
		String query = "select enclosure_id from enclosure";
		PreparedStatement pstmt = con.prepareStatement(query);
		ResultSet rs = pstmt.executeQuery();
		
		if(!rs.isBeforeFirst()) {
			return null;
		}
		
		while(rs.next()) {
			myList.add(rs.getInt("enclosure_id"));
		}
		
		
		closeConnection();
		
		return myList;
	}
	
	public static ArrayList<Integer> getAllDietID() throws ClassNotFoundException, SQLException{
		openConnection();
		
		ArrayList<Integer> myList = new ArrayList<>();
		
		String query = "select diet_id from diet";
		PreparedStatement pstmt = con.prepareStatement(query);
		ResultSet rs = pstmt.executeQuery();
		
		if(!rs.isBeforeFirst()) {
			return null;
		}
		
		while(rs.next()) {
			myList.add(rs.getInt("diet_id"));
		}
		
		
		closeConnection();
		
		return myList;
	}
	
	public static ArrayList<Animal>getAllAnimalInfo() throws ClassNotFoundException, SQLException{
		openConnection();
		
		ArrayList<Animal>myList=new ArrayList<>();
		
		String query="SELECT * FROM gowild_wildlife_park.animal;";
		PreparedStatement pstmt=con.prepareStatement(query);
		ResultSet rs=pstmt.executeQuery();
		
		if(!rs.isBeforeFirst()) {
			return null;
		}
		while(rs.next()) {
			Animal animal=new Animal();
			
			animal.setAnimal_id(rs.getInt("animal_id"));
			animal.setName(rs.getString("name"));
			animal.setDate_of_arrival(rs.getString("date_of_arrival"));
			animal.setDiet_id(rs.getInt("diet_id"));
			animal.setEnclosure_id(rs.getInt("enclosure_id"));
			animal.setGender(rs.getString("gender"));
			animal.setKeeper_id(rs.getInt("keeper_id"));
			animal.setSpecies_id(rs.getInt("species_id"));
			
			myList.add(animal);
		}
		closeConnection();
		return myList;
	}
	public static Keeper getKeepereInfoByID(int id) throws SQLException, ClassNotFoundException {
		openConnection();
		Keeper keeper=new Keeper();
		
		String query="select * from keeper where keeper_id=?";
		
		PreparedStatement pstmt=con.prepareStatement(query);
		
		pstmt.setInt(1,id);
		
		ResultSet rs=pstmt.executeQuery();
		
		if(!rs.isBeforeFirst()) {
			return null;
		}
		rs.next();
		keeper.setKeeper_id(rs.getInt("keeper_id"));
		keeper.setName(rs.getString("name"));
		keeper.setDob(String.valueOf(rs.getDate("dob")));
		keeper.setKeeper_rank(rs.getString("keeper_rank"));
		keeper.setPhno(rs.getString("phno"));
		keeper.setAddress(rs.getString("address"));
		keeper.setEmail(rs.getString("email"));
		closeConnection();
		return keeper;
	}
	public static Species getSpeciesInfoByID(int id) throws SQLException, ClassNotFoundException {

		openConnection();
		String query="select * from species where species_id=?";
		
		PreparedStatement pstmt=con.prepareStatement(query);
		
		pstmt.setInt(1, id);
		
		ResultSet rs=pstmt.executeQuery();
		
		if(!rs.isBeforeFirst()) {
			return null;
		}

			rs.next();
			Species species=new Species();
			
			species.setSpecies_id(rs.getInt("species_id"));
			species.setType(rs.getString("species_type"));
			species.setGroup(rs.getString("species_group"));
			species.setLifestyle(rs.getString("lifestyle"));
			species.setConservation(rs.getString("conservation_status"));
			
			closeConnection();
			return species;
	}
		
		public static Diet getDietInfoByID(int id) throws ClassNotFoundException, SQLException {
			openConnection();
			
			String query="select * from diet where diet_id = ?";
			PreparedStatement pstmt=con.prepareStatement(query);
			
			pstmt.setInt(1, id);
			
			ResultSet rs=pstmt.executeQuery();
			
			if(!rs.isBeforeFirst()) {
				return null;
			}
			rs.next();
			
			Diet diet=new Diet();
			diet.setDiet_id(rs.getInt("diet_id"));
			diet.setType(rs.getString("diet_type"));
			diet.setFeeds_per_day(rs.getInt("feeds_per_day"));
		closeConnection();
		return diet;
	}
		public static Enclosure getEnclosureInfoByID(int id) throws ClassNotFoundException, SQLException {
			openConnection();
			
			String query="select * from enclosure where enclosure_id=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1, id);
			
			ResultSet rs=pstmt.executeQuery();
			
			if(!rs.isBeforeFirst()) {
				return null;
			}
			rs.next();
			Enclosure enclosure=new Enclosure();
			
			enclosure.setEnclosure_id(rs.getInt("enclosure_id"));
			enclosure.setLocation(rs.getString("location"));
			enclosure.setType(rs.getString("enclosure_type"));
			
			
		closeConnection();
		return enclosure;
	}
		public static Animal getAnimalInfoByID(int id) throws ClassNotFoundException, SQLException {
			openConnection();
			Animal animal = new Animal();

			String query = "select * from animal where animal_id = ?";
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();

			if (!rs.isBeforeFirst()) {
				return null;
			}

			rs.next();

			animal.setAnimal_id(rs.getInt("animal_id"));
			animal.setName(rs.getString("name"));
			animal.setGender(rs.getString("gender"));
			animal.setDiet_id(rs.getInt("diet_id"));
			animal.setEnclosure_id(rs.getInt("enclosure_id"));
			animal.setKeeper_id(rs.getInt("keeper_id"));
			animal.setSpecies_id(rs.getInt("species_id"));
			animal.setDate_of_arrival(String.valueOf(rs.getDate("date_of_arrival")));

			closeConnection();
			return animal;
		}
		public static ArrayList<Report1> getReport1() throws ClassNotFoundException, SQLException {
			openConnection();
			ArrayList<Report1> myList = new ArrayList<>();

			String query = "select keeper.name as keeper_name, animal.animal_id,animal.name as animal_name,animal.gender,animal.date_of_arrival "
					+ "from animal " + "inner join keeper " + "on (animal.keeper_id=keeper.keeper_id) "
					+ "where keeper.name in ('Dave','Temi') " + "order by keeper.name";

			PreparedStatement pstmt = con.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();

			if (!rs.isBeforeFirst()) {
				return null;
			}

			while (rs.next()) {
				Report1 report1 = new Report1();
				report1.setKeeper_name(rs.getString("keeper_name"));
				report1.setAnimail_id(rs.getInt("animal_id"));
				report1.setAnimal_name(rs.getString("animal_name"));
				report1.setGender(rs.getString("gender"));
				report1.setDate_of_arrival(String.valueOf(rs.getDate("date_of_arrival")));

				myList.add(report1);
			}

			closeConnection();
			return myList;
		}

		public static int getTotalNoOfAnimal() throws ClassNotFoundException, SQLException {
			int totalAnimal = 0;
			openConnection();

			String query = "select count(animal_id) as total_animal from animal";
			PreparedStatement pstmt = con.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();

			if (!rs.isBeforeFirst()) {
				return 0;
			}

			rs.next();
			totalAnimal = rs.getInt("total_animal");

			closeConnection();
			return totalAnimal;
		}

		public static ArrayList<Report2> getReport2() throws ClassNotFoundException, SQLException {
			openConnection();

			ArrayList<Report2> myList = new ArrayList<>();
			String query = "select * from report2";

			PreparedStatement pstmt = con.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();

			if (!rs.isBeforeFirst()) {
				return null;
			}
			
			while(rs.next()) {
				Report2 report2 = new Report2();
				report2.setKeeper_name(rs.getString("keeper_name"));
				report2.setTotal_animal(rs.getInt("total_animal"));
				myList.add(report2);
			}

			closeConnection();

			return myList;
		}
}
	

	

	

