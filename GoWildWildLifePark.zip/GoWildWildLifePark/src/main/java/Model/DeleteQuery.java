package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DBHandler.DBConnection;

public class DeleteQuery {
	
	private static Connection con;
	private static void openConnection() throws ClassNotFoundException, SQLException {
		con=DBConnection.getConnection();
	}
	private static void closeConnection() throws SQLException {
		con.close();
	}
	
	public static int deleteKeeperInfo(int id) throws ClassNotFoundException, SQLException {
		openConnection();
		int row=0;
		
		String query="delete from keeper where keeper_id=?";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setInt(1, id);
		row=pstmt.executeUpdate();
		
		closeConnection();
		return row;
	}
	public static int deleteSpeciesInfo(int id) throws ClassNotFoundException, SQLException {
		openConnection();
		int row=0;
		
		String query="delete from species where species_id=?";
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setInt(1, id);
		row=pstmt.executeUpdate();
		
		closeConnection();
		return row;
	}
	public static int deleteDietInfo(int id) throws ClassNotFoundException, SQLException {
		openConnection();
		
		int row=0;
		String query="delete from diet where diet_id=?";
		
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setInt(1, id);
		row=pstmt.executeUpdate();
		
		closeConnection();
		return row;
		
	}
	public static int deleteEnclosureInfo(int id) throws ClassNotFoundException, SQLException {
		openConnection();
		
		int row=0;
		String query="delete from enclosure where enclosure_id=?";
		
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setInt(1, id);
		row=pstmt.executeUpdate();
		
		closeConnection();
		return row;
	}
	public static int deleteAnimalInfo(int id) throws ClassNotFoundException, SQLException {
		openConnection();
		int row=0;
		String query="delete from animal where animal_id=?";
		
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setInt(1, id);
		row=pstmt.executeUpdate();
		closeConnection();
		return row;
	}
}
	
	
	


