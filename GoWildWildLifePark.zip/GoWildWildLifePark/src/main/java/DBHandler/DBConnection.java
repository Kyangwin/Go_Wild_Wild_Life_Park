package DBHandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=null;
		String dbur1="jdbc:mysql://localhost:3306/gowild_wildlife_park";
		String username="root";
		String password="root";
		
		con=DriverManager.getConnection(dbur1,username,password);
		return con;
	}

}
