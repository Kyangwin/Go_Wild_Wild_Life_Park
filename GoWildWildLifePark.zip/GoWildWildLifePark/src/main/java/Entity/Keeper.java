package Entity;

public class Keeper {
	private int keeper_id;
	public int getKeeper_id() {
		return keeper_id;
	}
	public void setKeeper_id(int keeper_id) {
		this.keeper_id = keeper_id;
	}
	private String name;
	private String keeper_rank;
	private String dob;
	private String phno;
	private String email;
	private String address;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getKeeper_rank() {
		return keeper_rank;
	}
	public void setKeeper_rank(String keeper_rank) {
		this.keeper_rank = keeper_rank;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = phno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

}
