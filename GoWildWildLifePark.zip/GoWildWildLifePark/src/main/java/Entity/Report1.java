package Entity;

public class Report1 {
	private String keeper_name;
	private int animail_id;
	private String gender;
	private String date_of_arrival;
	private String animal_name;
	public String getKeeper_name() {
		return keeper_name;
	}
	public void setKeeper_name(String keeper_name) {
		this.keeper_name = keeper_name;
	}
	public int getAnimail_id() {
		return animail_id;
	}
	public void setAnimail_id(int animail_id) {
		this.animail_id = animail_id;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDate_of_arrival() {
		return date_of_arrival;
	}
	public void setDate_of_arrival(String date_of_arrival) {
		this.date_of_arrival = date_of_arrival;
	}
	public String getAnimal_name() {
		return animal_name;
	}
	public void setAnimal_name(String animal_name) {
		this.animal_name = animal_name;
	}

	
}
