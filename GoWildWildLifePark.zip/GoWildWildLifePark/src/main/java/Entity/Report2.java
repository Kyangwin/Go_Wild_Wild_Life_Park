package Entity;

public class Report2 {
	private String keeper_name;
	private int total_animal;

	public String getKeeper_name() {
		return keeper_name;
	}

	public void setKeeper_name(String keeper_name) {
		this.keeper_name = keeper_name;
	}

	public int getTotal_animal() {
		return total_animal;
	}

	public void setTotal_animal(int total_animal) {
		this.total_animal = total_animal;
	}

}