package Entity;

public class Enclosure {
	private int enclosure_id;
	private String type;
	private String location;
	
	public int getEnclosure_id() {
		return enclosure_id;
	}
	public void setEnclosure_id(int enclosure_id) {
		this.enclosure_id = enclosure_id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
}
