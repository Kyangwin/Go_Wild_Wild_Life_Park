package Entity;

public class Species {
	private int species_id;
	private String group;
	private String type;
	private String lifestyle;
	private String conservation;
	public int getSpecies_id() {
		return species_id;
	}
	public void setSpecies_id(int species_id) {
		this.species_id = species_id;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getConservation() {
		return conservation;
	}
	
	public String getLifestyle() {
		return lifestyle;
	}
	public void setLifestyle(String lifestyle) {
		this.lifestyle = lifestyle;
	}
	public void setConservation(String conservation) {
		this.conservation = conservation;
	}
	

}
